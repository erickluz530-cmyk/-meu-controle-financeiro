# Como gerar o APK da versão 2.0


1. Envie este projeto ao seu repositório GitHub (incluindo `.github/workflows/build-apk.yml`).
2. Abra a aba **Actions** do repositório.
3. Se necessário, confirme a habilitação de GitHub Actions.
4. Aguarde a execução **Build Android APK** ficar verde.
5. Abra a execução concluída e, em **Artifacts**, baixe `Meu-Controle-Financeiro-2.0-debug-apk`.
6. Extraia o ZIP do artifact e instale `app-debug.apk` no Android.


Este APK de debug é assinado com a chave de depuração gerada pelo Android Gradle Plugin. Para atualização sobre uma versão instalada anteriormente, o APK precisa usar a mesma chave de assinatura da versão instalada. Caso contrário, o Android pode exigir que a versão antiga seja desinstalada (o que pode apagar dados locais); faça backup antes.
