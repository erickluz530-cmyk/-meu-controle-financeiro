plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.meucontrolefinanceiro"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.meucontrolefinanceiro"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
